# AMP_LLMs
LLM scripts for AMP Clinical Trial model

# Run the program
python main

# Commands available within program
main menu --> returns user to operation mode selection (terminal vs llm workflow)

# SSH into Mac directly
ssh emilyzhang@100.99.162.98

# data_fetcher_tester.py
this tests the json payload delivered by the various APIs (4x PubMed APIs, Clinical Trials API, DuckDuckGo API)
import os
import sys
import platform
import subprocess
import shutil
import getpass
from concurrent.futures import ThreadPoolExecutor, as_completed

VENV_DIR = "llm_env"


# --- VENV SETUP ---

def get_python_path():
    if platform.system() == "Windows":
        return os.path.join(VENV_DIR, "Scripts", "python.exe")
    else:
        return os.path.join(VENV_DIR, "bin", "python")

def check_virtual_env():
    python_path = get_python_path()
    if os.path.exists(python_path):
        try:
            subprocess.run([python_path, "--version"], check=True, capture_output=True)
            return True
        except Exception:
            print("Existing virtual environment is broken. Removing...")
            shutil.rmtree(VENV_DIR)
    return False

def create_virtual_env():
    print("Creating virtual environment...")
    subprocess.check_call([sys.executable, "-m", "venv", VENV_DIR])

def ensure_requirements():
    requirements_file = "requirements.txt"
    if not os.path.exists(requirements_file):
        with open(requirements_file, "w") as f:
            f.write("paramiko\npandas\nopenpyxl\n")

    python_path = get_python_path()
    print("Installing dependencies...")
    subprocess.check_call([python_path, "-m", "pip", "install", "--upgrade", "pip"])
    subprocess.check_call([python_path, "-m", "pip", "install", "-r", requirements_file])

def setup_environment():
    if not check_virtual_env():
        create_virtual_env()

    python_path = get_python_path()
    if os.path.abspath(sys.executable) != os.path.abspath(python_path):
        print("Restarting inside virtual environment...")
        subprocess.check_call([python_path] + sys.argv)
        sys.exit(0)

    ensure_requirements()


# --- NETWORKING ---

def ping_host(hostname, count=5, timeout=1000):
    print(f"Pinging {hostname} {count} times with timeout={timeout}ms...")
    system = platform.system().lower()
    if system == "windows":
        cmd = ["ping", "-n", str(count), "-w", str(timeout), hostname]
    else:
        timeout_sec = str(int(timeout) // 1000)
        cmd = ["ping", "-c", str(count), "-W", timeout_sec, hostname]

    try:
        result = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        if result.returncode == 0:
            print("Ping successful.\n")
            return True
        else:
            print("Ping failed.\n")
            return False
    except Exception as e:
        print(f"Error during ping: {e}")
        return False

def prompt_for_reachable_host(max_attempts=5, timeout=1000):
    while True:
        hostname = input("Enter SSH host (e.g., 100.99.162.98): ").strip()
        if ping_host(hostname, count=max_attempts, timeout=timeout):
            return hostname

        print("Could not reach host.")
        choice = input("Try another IP? (y/n): ").strip().lower()
        if choice != 'y':
            print("Aborting.")
            return None


# --- SSH CONNECTION ---

def connect_ssh(hostname, username, password):
    import paramiko
    ssh_client = paramiko.SSHClient()
    ssh_client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    try:
        ssh_client.connect(hostname=hostname, username=username, password=password)
        return ssh_client
    except Exception as e:
        print(f"SSH connection failed: {e}")
        return None


# --- LLM WORKFLOW ---

def run_llm_workflow(ssh_client):
    import pandas as pd
    from openpyxl import load_workbook

    llms = {
        '1': 'deepseek-coder:6.7b',
        '2': 'deepseek-llm:7b',
        '3': 'llama2:7b',
        '4': 'llama2:13b',
        '5': 'llama2:70b',
        '6': 'mistral',
        '7': 'mixtral',
        '8': 'gemma',
        '9': 'gemma:2b',
        '10': 'phi3',
        '11': 'command-r',
        '12': 'dolphin-mixtral',
        '13': 'openhermes'
    }

    print("\nAvailable LLMs:")
    for key, val in llms.items():
        print(f"{key}. {val}")
    print("L. List local models via `ollama list`")

    choice = input("Enter choice number (or 'L'): ").strip().lower()

    if choice == 'l':
        subprocess.run(["ollama", "list"])
        return

    if choice not in llms:
        print("Invalid choice.")
        return

    model_name = llms[choice]

    # Pull model if not installed
    print(f"Checking model '{model_name}' locally...")
    list_result = subprocess.run(["ollama", "list"], capture_output=True, text=True)
    if model_name not in list_result.stdout:
        print(f"Model '{model_name}' not found locally. Pulling it...")
        subprocess.run(["ollama", "pull", model_name])

    # Load prompts
    csv_file = input("Enter CSV file path with prompts: ").strip()
    try:
        df_prompts = pd.read_csv(csv_file)
    except Exception as e:
        print(f"Error reading CSV: {e}")
        return

    if 'Prompt' not in df_prompts.columns:
        print("CSV must have a 'Prompt' column.")
        return

    prompts = df_prompts['Prompt'].tolist()
    responses = []

    def run_prompt(prompt):
        try:
            result = subprocess.run(
                ["ollama", "run", model_name],
                input=prompt,
                text=True,
                capture_output=True
            )
            return (prompt, result.stdout.strip())
        except Exception as e:
            return (prompt, f"Error: {e}")

    with ThreadPoolExecutor(max_workers=5) as executor:
        future_to_prompt = {executor.submit(run_prompt, p): p for p in prompts}
        for future in as_completed(future_to_prompt):
            responses.append(future.result())

    # Save responses
    output_file = input("Enter output Excel file path: ").strip()
    df = pd.DataFrame(responses, columns=['Prompt', 'Response'])

    try:
        book = load_workbook(output_file)
        writer = pd.ExcelWriter(output_file, engine='openpyxl')
        writer.book = book
        startrow = book['Sheet1'].max_row if 'Sheet1' in book.sheetnames else 0
        df.to_excel(writer, sheet_name='Sheet1', index=False, header=startrow == 0, startrow=startrow)
        writer.save()
        writer.close()
    except FileNotFoundError:
        df.to_excel(output_file, index=False)

    print(f"\nResponses saved to {output_file}")


# --- MAIN ---

def main():
    setup_environment()

    hostname = prompt_for_reachable_host()
    if not hostname:
        return

    username = input("Enter SSH username: ").strip()
    password = getpass.getpass(f"Password for {username}@{hostname}: ")

    ssh_client = connect_ssh(hostname, username, password)
    if ssh_client:
        run_llm_workflow(ssh_client)
        ssh_client.close()


if __name__ == "__main__":
    main()

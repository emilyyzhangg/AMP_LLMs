import subprocess
import sys
import os
import platform

VENV_DIR = "llm_env"  # Virtual environment folder
REQUIREMENTS_FILE = os.path.join(
    os.path.dirname(os.path.abspath(__file__)),
    "requirements.txt"
)

def create_virtual_env():
    if not os.path.exists(VENV_DIR):
        print(f"Creating virtual environment in ./{VENV_DIR}")
        subprocess.check_call([sys.executable, "-m", "venv", VENV_DIR])
    else:
        print(f"Virtual environment '{VENV_DIR}' already exists.")

def get_python_path():
    """Return the Python executable inside the virtual environment."""
    if platform.system() == "Windows":
        return os.path.join(VENV_DIR, "Scripts", "python.exe")
    else:
        return os.path.join(VENV_DIR, "bin", "python")

def install_requirements():
    print(f"Looking for requirements at: {REQUIREMENTS_FILE}")
    folder = os.path.dirname(os.path.abspath(__file__))
    print("Looking in:", folder)
    print("Files in folder:")
    for f in os.listdir(folder):
        print(repr(f))
    print(os.path.dirname(os.path.abspath(__file__)))
    python_path = get_python_path()
    print("Upgrading pip inside virtual environment...")
    subprocess.check_call([python_path, "-m", "pip", "install", "--upgrade", "pip"])
    print("Installing requirements from requirements.txt...")
    subprocess.check_call([python_path, "-m", "pip", "install", "-r", REQUIREMENTS_FILE])

def main():
    create_virtual_env()
    install_requirements()
    
    print("\nVirtual environment setup complete.")
    if platform.system() == "Windows":
        print(f"Activate with: {VENV_DIR}\\Scripts\\activate.bat")
    else:
        print(f"Activate with: source {VENV_DIR}/bin/activate")
    print("Then run your main script, e.g.: python main.py")

if __name__ == "__main__":
    main()

"""
LLM utility functions for Ollama interaction.
Improved with configurable timeouts and better error handling.
"""
import asyncio
import shlex
import re
from config import get_config, get_logger

logger = get_logger(__name__)
config = get_config()

# ANSI escape sequence pattern
ANSI_ESCAPE = re.compile(r'(?:\x1B[@-_][0-?]*[ -/]*[@-~])')


def clean(text: str) -> str:
    """Remove ANSI escape sequences from text."""
    return ANSI_ESCAPE.sub('', text).strip()


async def list_remote_models(ssh):
    """
    List available Ollama models on remote host.
    Returns list of model names or empty list if none found.
    """
    try:
        logger.info("Listing remote Ollama models")
        result = await ssh.run('ollama list', check=False)
        out = result.stdout or result.stderr
        
        if not out or 'NAME' not in out:
            logger.warning("No Ollama models found or ollama not installed")
            return []
        
        models = []
        for line in out.splitlines():
            line = line.strip()
            if not line or line.lower().startswith('name'):
                continue
            
            parts = line.split()
            if parts:
                models.append(parts[0])
        
        logger.info(f"Found {len(models)} models: {', '.join(models)}")
        return models
        
    except Exception as e:
        logger.error(f"Error listing models: {e}", exc_info=True)
        return []


async def start_persistent_ollama(ssh, model: str):
    """
    Start persistent ollama run process and return process handle.
    Uses ssh.create_process to get stdin/stdout as streams.
    
    Args:
        ssh: AsyncSSH connection
        model: Model name to run
        
    Returns:
        Process handle with stdin/stdout
        
    Raises:
        Exception if process fails to start
    """
    logger.info(f"Starting persistent Ollama process for model: {model}")
    
    try:
        proc = await ssh.create_process(
            f'ollama run {shlex.quote(model)}',
            term_type='xterm'
        )
        
        # Wait a moment for process to initialize
        await asyncio.sleep(1)
        
        logger.info(f"Ollama process started for {model}")
        return proc
        
    except Exception as e:
        logger.error(f"Failed to start Ollama: {e}", exc_info=True)
        raise


async def send_and_stream(proc, prompt: str) -> str:
    """
    Send prompt to Ollama and stream response until idle timeout.
    
    Args:
        proc: Process handle from start_persistent_ollama
        prompt: User prompt to send
        
    Returns:
        Cleaned response text
    """
    logger.debug(f"Sending prompt: {prompt[:50]}...")
    
    # Write prompt
    try:
        proc.stdin.write(prompt + "\n")
        await proc.stdin.drain()
    except Exception as e:
        logger.error(f"Error writing prompt: {e}")
        raise
    
    # Read response with idle timeout
    output = []
    idle_count = 0
    max_idle = config.llm.idle_timeout
    
    while True:
        try:
            chunk = await asyncio.wait_for(
                proc.stdout.read(config.llm.stream_chunk_size),
                timeout=1.0
            )
            
            if not chunk:
                break
            
            output.append(chunk)
            idle_count = 0  # Reset idle counter
            
        except asyncio.TimeoutError:
            idle_count += 1
            if idle_count > max_idle:
                logger.debug(f"Idle timeout reached after {max_idle} seconds")
                break
            continue
        except Exception as e:
            logger.error(f"Error reading output: {e}")
            break
    
    response = clean(''.join(output))
    logger.debug(f"Received response: {len(response)} characters")
    
    return response